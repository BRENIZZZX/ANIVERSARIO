package com.siterosa.dto;

/**
 * DTO para resposta de autenticação
 * 
 * Usado para retornar dados após login bem-sucedido
 * Contém o token JWT e informações básicas do usuário
 */
public class AuthResponse {
    
    /**
     * Token JWT para autenticação
     * Este token deve ser enviado nas próximas requisições
     * no header Authorization: Bearer <token>
     */
    private String token;
    
    /**
     * Tipo do token (sempre "Bearer" para JWT)
     */
    private String type = "Bearer";
    
    /**
     * Informações básicas do usuário
     * Objeto aninhado com dados do usuário logado
     */
    private UserInfo user;
    
    /**
     * Construtor padrão
     */
    public AuthResponse() {
    }
    
    /**
     * Construtor com parâmetros
     * 
     * @param token token JWT
     * @param user informações do usuário
     */
    public AuthResponse(String token, UserInfo user) {
        this.token = token;
        this.user = user;
    }
    
    // Getters e Setters
    
    public String getToken() {
        return token;
    }
    
    public void setToken(String token) {
        this.token = token;
    }
    
    public String getType() {
        return type;
    }
    
    public void setType(String type) {
        this.type = type;
    }
    
    public UserInfo getUser() {
        return user;
    }
    
    public void setUser(UserInfo user) {
        this.user = user;
    }
    
    /**
     * Classe interna para informações do usuário
     * Contém apenas dados não sensíveis que podem ser expostos
     */
    public static class UserInfo {
        private Long id;
        private String username;
        private String email;
        private String createdAt;
        
        /**
         * Construtor padrão
         */
        public UserInfo() {
        }
        
        /**
         * Construtor com parâmetros
         * 
         * @param id ID do usuário
         * @param username nome de usuário
         * @param email email do usuário
         * @param createdAt data de criação da conta
         */
        public UserInfo(Long id, String username, String email, String createdAt) {
            this.id = id;
            this.username = username;
            this.email = email;
            this.createdAt = createdAt;
        }
        
        // Getters e Setters
        
        public Long getId() {
            return id;
        }
        
        public void setId(Long id) {
            this.id = id;
        }
        
        public String getUsername() {
            return username;
        }
        
        public void setUsername(String username) {
            this.username = username;
        }
        
        public String getEmail() {
            return email;
        }
        
        public void setEmail(String email) {
            this.email = email;
        }
        
        public String getCreatedAt() {
            return createdAt;
        }
        
        public void setCreatedAt(String createdAt) {
            this.createdAt = createdAt;
        }
    }
}