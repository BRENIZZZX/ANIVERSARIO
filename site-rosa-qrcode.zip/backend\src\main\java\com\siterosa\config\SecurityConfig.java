package com.siterosa.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import java.util.Arrays;

/**
 * Configuração de segurança do Spring Security
 * 
 * Define:
 * - Quais endpoints são públicos/protegidos
 * - Configuração de CORS
 * - Encoder de senhas
 * - Política de sessões (stateless para JWT)
 */
@Configuration
@EnableWebSecurity
public class SecurityConfig {
    
    /**
     * Configura a cadeia de filtros de segurança
     * 
     * @param http objeto HttpSecurity para configuração
     * @return SecurityFilterChain configurado
     * @throws Exception em caso de erro na configuração
     */
    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
            // Desabilita CSRF (Cross-Site Request Forgery) pois usamos JWT
            // JWT é stateless e não precisa de proteção CSRF
            .csrf(csrf -> csrf.disable())
            
            // Configura CORS (Cross-Origin Resource Sharing)
            // Permite requisições do frontend React
            .cors(cors -> cors.configurationSource(corsConfigurationSource()))
            
            // Configura autorização de requisições
            .authorizeHttpRequests(authz -> authz
                // Endpoints públicos (não precisam de autenticação)
                .requestMatchers("/api/auth/**").permitAll()     // Login, cadastro, health
                .requestMatchers("/api/qr/**").permitAll()       // QR Code endpoints
                .requestMatchers("/error").permitAll()          // Páginas de erro
                .requestMatchers("/actuator/health").permitAll() // Health check
                
                // Todos os outros endpoints precisam de autenticação
                .anyRequest().authenticated()
            )
            
            // Configura política de sessões como STATELESS
            // Não cria sessões HTTP, usa apenas JWT
            .sessionManagement(session -> 
                session.sessionCreationPolicy(SessionCreationPolicy.STATELESS)
            );
        
        return http.build();
    }
    
    /**
     * Configura o encoder de senhas
     * 
     * BCrypt é um algoritmo de hash seguro que:
     * - Adiciona salt automaticamente
     * - É resistente a ataques de força bruta
     * - Tem custo computacional ajustável
     * 
     * @return PasswordEncoder configurado
     */
    @Bean
    public PasswordEncoder passwordEncoder() {
        // Força 12 = bom equilíbrio entre segurança e performance
        // Cada incremento dobra o tempo de processamento
        return new BCryptPasswordEncoder(12);
    }
    
    /**
     * Configura CORS (Cross-Origin Resource Sharing)
     * 
     * Permite que o frontend React (localhost:5173) faça requisições
     * para o backend (localhost:8080)
     * 
     * @return CorsConfigurationSource configurado
     */
    @Bean
    public CorsConfigurationSource corsConfigurationSource() {
        CorsConfiguration configuration = new CorsConfiguration();
        
        // Origens permitidas (frontend React)
        configuration.setAllowedOriginPatterns(Arrays.asList(
            "http://localhost:5173",
            "http://127.0.0.1:5173",
            "http://localhost:3000"  // Caso use Create React App
        ));
        
        // Métodos HTTP permitidos
        configuration.setAllowedMethods(Arrays.asList(
            "GET", "POST", "PUT", "DELETE", "OPTIONS", "PATCH"
        ));
        
        // Headers permitidos
        configuration.setAllowedHeaders(Arrays.asList(
            "Authorization",
            "Content-Type",
            "X-Requested-With",
            "Accept",
            "Origin",
            "Access-Control-Request-Method",
            "Access-Control-Request-Headers"
        ));
        
        // Headers expostos (que o frontend pode acessar)
        configuration.setExposedHeaders(Arrays.asList(
            "Access-Control-Allow-Origin",
            "Access-Control-Allow-Credentials",
            "Authorization"
        ));
        
        // Permite envio de cookies/credenciais
        configuration.setAllowCredentials(true);
        
        // Tempo de cache para requisições preflight (OPTIONS)
        configuration.setMaxAge(3600L);
        
        // Aplica configuração para todas as URLs
        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", configuration);
        
        return source;
    }
}