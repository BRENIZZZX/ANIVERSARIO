package com.siterosa.repository;

import com.siterosa.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;

/**
 * Repository para a entidade User
 * 
 * @Repository: marca como componente de acesso a dados
 * JpaRepository<User, Long>: fornece métodos CRUD básicos
 * - User: tipo da entidade
 * - Long: tipo da chave primária
 */
@Repository
public interface UserRepository extends JpaRepository<User, Long> {
    
    /**
     * Busca usuário por email
     * Spring Data JPA gera automaticamente a implementação
     * baseada no nome do método
     * 
     * @param email email do usuário
     * @return Optional<User> - pode estar presente ou não
     */
    Optional<User> findByEmail(String email);
    
    /**
     * Busca usuário por nome de usuário
     * 
     * @param username nome de usuário
     * @return Optional<User> - pode estar presente ou não
     */
    Optional<User> findByUsername(String username);
    
    /**
     * Verifica se existe usuário com o email informado
     * Útil para validação antes de criar novo usuário
     * 
     * @param email email a ser verificado
     * @return true se existe, false caso contrário
     */
    boolean existsByEmail(String email);
    
    /**
     * Verifica se existe usuário com o username informado
     * 
     * @param username nome de usuário a ser verificado
     * @return true se existe, false caso contrário
     */
    boolean existsByUsername(String username);
    
    /**
     * Busca usuário por email ou username
     * Query personalizada usando @Query
     * Útil para login que aceita email ou username
     * 
     * @param email email do usuário
     * @param username nome de usuário
     * @return Optional<User> - usuário encontrado ou vazio
     */
    @Query("SELECT u FROM User u WHERE u.email = :email OR u.username = :username")
    Optional<User> findByEmailOrUsername(@Param("email") String email, 
                                       @Param("username") String username);
    
    /**
     * Conta total de usuários cadastrados
     * Método gerado automaticamente pelo Spring Data JPA
     * 
     * @return número total de usuários
     */
    long count();
    
    /**
     * Busca usuários por parte do nome de usuário (busca parcial)
     * Útil para funcionalidades de busca/autocomplete
     * 
     * @param username parte do nome de usuário
     * @return lista de usuários que contêm o texto no username
     */
    @Query("SELECT u FROM User u WHERE u.username LIKE %:username%")
    java.util.List<User> findByUsernameContaining(@Param("username") String username);
}