package com.siterosa.service;

import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Serviço para gerenciamento de tokens QR Code
 * 
 * Em produção, recomenda-se usar Redis para armazenamento distribuído
 * Aqui usamos ConcurrentHashMap para simplicidade e demonstração
 */
@Service
public class QRTokenService {
    
    /**
     * Mapa para armazenar tokens QR em memória
     * ConcurrentHashMap é thread-safe para acesso concorrente
     * 
     * Chave: token (String)
     * Valor: QRTokenData (dados do token)
     */
    private final ConcurrentHashMap<String, QRTokenData> qrTokens = new ConcurrentHashMap<>();
    
    /**
     * Tempo de vida padrão dos tokens em segundos (2 minutos)
     * Após este tempo, o token expira automaticamente
     */
    private static final int DEFAULT_TTL_SECONDS = 120;
    
    /**
     * Cria um novo token QR Code
     * 
     * @return token único gerado
     */
    public String createQRToken() {
        // Gera um UUID único para o token
        String token = UUID.randomUUID().toString();
        
        // Calcula o tempo de expiração
        LocalDateTime expiresAt = LocalDateTime.now().plusSeconds(DEFAULT_TTL_SECONDS);
        
        // Cria os dados do token
        QRTokenData tokenData = new QRTokenData(
            token,
            QRTokenStatus.PENDING,
            expiresAt,
            null // userId será definido quando aprovado
        );
        
        // Armazena no mapa
        qrTokens.put(token, tokenData);
        
        System.out.println("🔑 Token QR criado: " + token + " (expira em " + DEFAULT_TTL_SECONDS + "s)");
        
        return token;
    }
    
    /**
     * Obtém o status atual de um token QR
     * 
     * @param token token a ser consultado
     * @return dados do token ou null se não encontrado/expirado
     */
    public QRTokenData getTokenStatus(String token) {
        QRTokenData tokenData = qrTokens.get(token);
        
        if (tokenData == null) {
            return null; // Token não encontrado
        }
        
        // Verifica se o token expirou
        if (LocalDateTime.now().isAfter(tokenData.getExpiresAt())) {
            // Remove token expirado
            qrTokens.remove(token);
            System.out.println("⏰ Token QR expirado removido: " + token);
            return null;
        }
        
        return tokenData;
    }
    
    /**
     * Aprova um token QR Code
     * 
     * @param token token a ser aprovado
     * @param userId ID do usuário que aprovou
     * @return true se aprovado com sucesso, false caso contrário
     */
    public boolean approveToken(String token, Long userId) {
        QRTokenData tokenData = getTokenStatus(token);
        
        if (tokenData == null) {
            System.out.println("❌ Tentativa de aprovar token inexistente/expirado: " + token);
            return false; // Token não encontrado ou expirado
        }
        
        if (tokenData.getStatus() != QRTokenStatus.PENDING) {
            System.out.println("❌ Tentativa de aprovar token que não está PENDING: " + token);
            return false; // Token já foi processado
        }
        
        // Atualiza o status para aprovado
        tokenData.setStatus(QRTokenStatus.APPROVED);
        tokenData.setUserId(userId);
        
        System.out.println("✅ Token QR aprovado: " + token + " para usuário: " + userId);
        
        return true;
    }
    
    /**
     * Remove um token QR Code (usado após consumo)
     * 
     * @param token token a ser removido
     */
    public void removeToken(String token) {
        QRTokenData removed = qrTokens.remove(token);
        if (removed != null) {
            System.out.println("🗑️ Token QR removido: " + token);
        }
    }
    
    /**
     * Limpa tokens expirados (método de limpeza)
     * Em produção, seria executado por um scheduler
     */
    public void cleanupExpiredTokens() {
        LocalDateTime now = LocalDateTime.now();
        int removedCount = 0;
        
        // Itera sobre todos os tokens e remove os expirados
        qrTokens.entrySet().removeIf(entry -> {
            if (now.isAfter(entry.getValue().getExpiresAt())) {
                System.out.println("🧹 Removendo token expirado: " + entry.getKey());
                return true;
            }
            return false;
        });
        
        if (removedCount > 0) {
            System.out.println("🧹 Limpeza concluída: " + removedCount + " tokens expirados removidos");
        }
    }
    
    /**
     * Obtém o TTL padrão em segundos
     * 
     * @return TTL em segundos
     */
    public int getDefaultTTL() {
        return DEFAULT_TTL_SECONDS;
    }
    
    /**
     * Calcula tempo restante para expiração de um token
     * 
     * @param token token a ser verificado
     * @return segundos restantes ou -1 se token inválido
     */
    public int getTimeRemaining(String token) {
        QRTokenData tokenData = qrTokens.get(token);
        
        if (tokenData == null) {
            return -1; // Token não encontrado
        }
        
        LocalDateTime now = LocalDateTime.now();
        LocalDateTime expiresAt = tokenData.getExpiresAt();
        
        if (now.isAfter(expiresAt)) {
            return 0; // Já expirou
        }
        
        // Calcula diferença em segundos
        return (int) java.time.Duration.between(now, expiresAt).getSeconds();
    }
    
    /**
     * Classe interna para representar dados de um token QR
     */
    public static class QRTokenData {
        private String token;
        private QRTokenStatus status;
        private LocalDateTime expiresAt;
        private Long userId;
        
        public QRTokenData(String token, QRTokenStatus status, LocalDateTime expiresAt, Long userId) {
            this.token = token;
            this.status = status;
            this.expiresAt = expiresAt;
            this.userId = userId;
        }
        
        // Getters e Setters
        
        public String getToken() {
            return token;
        }
        
        public void setToken(String token) {
            this.token = token;
        }
        
        public QRTokenStatus getStatus() {
            return status;
        }
        
        public void setStatus(QRTokenStatus status) {
            this.status = status;
        }
        
        public LocalDateTime getExpiresAt() {
            return expiresAt;
        }
        
        public void setExpiresAt(LocalDateTime expiresAt) {
            this.expiresAt = expiresAt;
        }
        
        public Long getUserId() {
            return userId;
        }
        
        public void setUserId(Long userId) {
            this.userId = userId;
        }
    }
    
    /**
     * Enum para status do token QR
     */
    public enum QRTokenStatus {
        PENDING,    // Aguardando aprovação
        APPROVED,   // Aprovado
        EXPIRED     // Expirado
    }
}