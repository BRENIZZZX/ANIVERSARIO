package com.siterosa.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import java.time.LocalDateTime;

/**
 * Entidade User - representa um usuário no banco de dados
 * 
 * @Entity: marca a classe como uma entidade JPA
 * @Table: especifica o nome da tabela no banco de dados
 */
@Entity
@Table(name = "users")
public class User {
    
    /**
     * ID único do usuário
     * @Id: marca como chave primária
     * @GeneratedValue: gera automaticamente o valor (auto-increment)
     * @Column: especifica propriedades da coluna
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;
    
    /**
     * Nome de usuário
     * @NotBlank: não pode ser nulo ou vazio
     * @Size: define tamanho mínimo e máximo
     * @Column: unique=true garante que não haverá duplicatas
     */
    @NotBlank(message = "Nome de usuário é obrigatório")
    @Size(min = 3, max = 50, message = "Nome de usuário deve ter entre 3 e 50 caracteres")
    @Column(name = "username", nullable = false, unique = true, length = 50)
    private String username;
    
    /**
     * Email do usuário
     * @Email: valida formato de email
     * @NotBlank: não pode ser nulo ou vazio
     */
    @Email(message = "Email deve ter formato válido")
    @NotBlank(message = "Email é obrigatório")
    @Column(name = "email", nullable = false, unique = true, length = 100)
    private String email;
    
    /**
     * Hash da senha do usuário
     * Nunca armazenamos a senha em texto plano!
     * Usamos BCrypt para gerar o hash
     */
    @NotBlank(message = "Senha é obrigatória")
    @Column(name = "password_hash", nullable = false, length = 255)
    private String passwordHash;
    
    /**
     * Data e hora de criação da conta
     * @Column: updatable=false impede alteração após criação
     */
    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;
    
    /**
     * Data e hora da última atualização
     */
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;
    
    /**
     * Construtor padrão (obrigatório para JPA)
     */
    public User() {
    }
    
    /**
     * Construtor com parâmetros principais
     * 
     * @param username nome de usuário
     * @param email email do usuário
     * @param passwordHash hash da senha
     */
    public User(String username, String email, String passwordHash) {
        this.username = username;
        this.email = email;
        this.passwordHash = passwordHash;
        this.createdAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
    }
    
    /**
     * Método executado antes de persistir no banco
     * Define automaticamente a data de criação
     */
    @PrePersist
    protected void onCreate() {
        this.createdAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
    }
    
    /**
     * Método executado antes de atualizar no banco
     * Atualiza automaticamente a data de modificação
     */
    @PreUpdate
    protected void onUpdate() {
        this.updatedAt = LocalDateTime.now();
    }
    
    // Getters e Setters
    // Necessários para o JPA e para acesso aos dados
    
    public Long getId() {
        return id;
    }
    
    public void setId(Long id) {
        this.id = id;
    }
    
    public String getUsername() {
        return username;
    }
    
    public void setUsername(String username) {
        this.username = username;
    }
    
    public String getEmail() {
        return email;
    }
    
    public void setEmail(String email) {
        this.email = email;
    }
    
    public String getPasswordHash() {
        return passwordHash;
    }
    
    public void setPasswordHash(String passwordHash) {
        this.passwordHash = passwordHash;
    }
    
    public LocalDateTime getCreatedAt() {
        return createdAt;
    }
    
    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }
    
    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }
    
    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }
    
    /**
     * Método toString para debug
     * Não inclui a senha por segurança
     */
    @Override
    public String toString() {
        return "User{" +
                "id=" + id +
                ", username='" + username + '\'' +
                ", email='" + email + '\'' +
                ", createdAt=" + createdAt +
                '}';
    }
}