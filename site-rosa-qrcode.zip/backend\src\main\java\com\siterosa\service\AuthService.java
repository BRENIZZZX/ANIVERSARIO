package com.siterosa.service;

import com.siterosa.dto.*;
import com.siterosa.entity.User;
import com.siterosa.repository.UserRepository;
import com.siterosa.security.JwtUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.time.format.DateTimeFormatter;
import java.util.Optional;

/**
 * Serviço de autenticação
 * 
 * Contém a lógica de negócio para:
 * - Cadastro de usuários
 * - Login tradicional
 * - Login via QR Code
 */
@Service
public class AuthService {
    
    /**
     * Repository para acesso aos dados de usuário
     */
    @Autowired
    private UserRepository userRepository;
    
    /**
     * Encoder para hash de senhas (BCrypt)
     * Configurado automaticamente pelo Spring Security
     */
    @Autowired
    private PasswordEncoder passwordEncoder;
    
    /**
     * Utilitário para geração e validação de tokens JWT
     */
    @Autowired
    private JwtUtils jwtUtils;
    
    /**
     * Serviço para gerenciamento de tokens QR
     */
    @Autowired
    private QRTokenService qrTokenService;
    
    /**
     * Cadastra um novo usuário
     * 
     * @param signupRequest dados do usuário a ser cadastrado
     * @return resposta indicando sucesso ou falha
     */
    public AuthResponse signup(SignupRequest signupRequest) {
        // Verifica se email já está em uso
        if (userRepository.existsByEmail(signupRequest.getEmail())) {
            throw new RuntimeException("Email já está em uso!");
        }
        
        // Verifica se username já está em uso
        if (userRepository.existsByUsername(signupRequest.getUsername())) {
            throw new RuntimeException("Nome de usuário já está em uso!");
        }
        
        // Cria novo usuário
        User user = new User();
        user.setUsername(signupRequest.getUsername());
        user.setEmail(signupRequest.getEmail());
        
        // Gera hash da senha usando BCrypt
        // BCrypt adiciona salt automaticamente e é resistente a ataques de força bruta
        String hashedPassword = passwordEncoder.encode(signupRequest.getPassword());
        user.setPasswordHash(hashedPassword);
        
        // Salva no banco de dados
        User savedUser = userRepository.save(user);
        
        System.out.println("👤 Novo usuário cadastrado: " + savedUser.getEmail());
        
        // Gera token JWT para login automático
        String jwt = jwtUtils.generateJwtToken(savedUser.getEmail());
        
        // Cria informações do usuário para resposta
        AuthResponse.UserInfo userInfo = new AuthResponse.UserInfo(
            savedUser.getId(),
            savedUser.getUsername(),
            savedUser.getEmail(),
            savedUser.getCreatedAt().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME)
        );
        
        return new AuthResponse(jwt, userInfo);
    }
    
    /**
     * Realiza login tradicional (email + senha)
     * 
     * @param loginRequest dados de login
     * @return resposta com token JWT e dados do usuário
     */
    public AuthResponse login(LoginRequest loginRequest) {
        // Busca usuário por email
        Optional<User> userOptional = userRepository.findByEmail(loginRequest.getEmail());
        
        if (userOptional.isEmpty()) {
            throw new RuntimeException("Usuário não encontrado!");
        }
        
        User user = userOptional.get();
        
        // Verifica se a senha está correta
        // passwordEncoder.matches() compara a senha em texto plano com o hash armazenado
        if (!passwordEncoder.matches(loginRequest.getPassword(), user.getPasswordHash())) {
            throw new RuntimeException("Senha incorreta!");
        }
        
        System.out.println("🔐 Login realizado: " + user.getEmail());
        
        // Gera token JWT
        String jwt = jwtUtils.generateJwtToken(user.getEmail());
        
        // Cria informações do usuário para resposta
        AuthResponse.UserInfo userInfo = new AuthResponse.UserInfo(
            user.getId(),
            user.getUsername(),
            user.getEmail(),
            user.getCreatedAt().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME)
        );
        
        return new AuthResponse(jwt, userInfo);
    }
    
    /**
     * Cria um novo token QR Code
     * 
     * @return resposta com token e TTL
     */
    public QRTokenResponse createQRToken() {
        String token = qrTokenService.createQRToken();
        int ttl = qrTokenService.getDefaultTTL();
        
        return new QRTokenResponse(token, ttl);
    }
    
    /**
     * Consulta o status de um token QR
     * 
     * @param token token a ser consultado
     * @return resposta com status atual
     */
    public QRStatusResponse getQRStatus(String token) {
        QRTokenService.QRTokenData tokenData = qrTokenService.getTokenStatus(token);
        
        if (tokenData == null) {
            // Token não encontrado ou expirado
            return new QRStatusResponse("EXPIRED", null);
        }
        
        switch (tokenData.getStatus()) {
            case PENDING:
                // Token ainda aguardando aprovação
                int timeRemaining = qrTokenService.getTimeRemaining(token);
                return new QRStatusResponse("PENDING", timeRemaining);
                
            case APPROVED:
                // Token foi aprovado, busca dados do usuário e gera JWT
                Optional<User> userOptional = userRepository.findById(tokenData.getUserId());
                
                if (userOptional.isEmpty()) {
                    return new QRStatusResponse("EXPIRED", null);
                }
                
                User user = userOptional.get();
                
                // Gera token JWT
                String jwt = jwtUtils.generateJwtToken(user.getEmail());
                
                // Cria informações do usuário
                AuthResponse.UserInfo userInfo = new AuthResponse.UserInfo(
                    user.getId(),
                    user.getUsername(),
                    user.getEmail(),
                    user.getCreatedAt().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME)
                );
                
                // Remove o token QR após uso (uso único)
                qrTokenService.removeToken(token);
                
                System.out.println("✅ Login via QR Code concluído: " + user.getEmail());
                
                return new QRStatusResponse("APPROVED", jwt, userInfo);
                
            default:
                return new QRStatusResponse("EXPIRED", null);
        }
    }
    
    /**
     * Aprova um token QR Code
     * 
     * @param approvalRequest dados da aprovação
     * @return true se aprovado com sucesso
     */
    public boolean approveQRToken(QRApprovalRequest approvalRequest) {
        // Busca usuário por email
        Optional<User> userOptional = userRepository.findByEmail(approvalRequest.getEmail());
        
        if (userOptional.isEmpty()) {
            throw new RuntimeException("Usuário não encontrado!");
        }
        
        User user = userOptional.get();
        
        // Aprova o token QR
        boolean approved = qrTokenService.approveToken(approvalRequest.getToken(), user.getId());
        
        if (approved) {
            System.out.println("📱 QR Code aprovado por: " + user.getEmail() + " para token: " + approvalRequest.getToken());
        }
        
        return approved;
    }
    
    /**
     * Busca usuário por email (usado para validação de JWT)
     * 
     * @param email email do usuário
     * @return usuário encontrado ou null
     */
    public User findByEmail(String email) {
        return userRepository.findByEmail(email).orElse(null);
    }
}