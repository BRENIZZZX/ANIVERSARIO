package com.siterosa.controller;

import com.siterosa.dto.QRApprovalRequest;
import com.siterosa.dto.QRStatusResponse;
import com.siterosa.dto.QRTokenResponse;
import com.siterosa.service.AuthService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

/**
 * Controller para endpoints relacionados ao QR Code
 * 
 * Gerencia o fluxo completo de login via QR Code:
 * 1. Criação de token QR
 * 2. Consulta de status
 * 3. Aprovação do token
 */
@RestController
@RequestMapping("/api/qr")
@CrossOrigin(origins = {"http://localhost:5173", "http://127.0.0.1:5173"})
public class QRController {
    
    /**
     * Serviço de autenticação
     */
    @Autowired
    private AuthService authService;
    
    /**
     * Endpoint para criar um novo token QR Code
     * 
     * POST /api/qr/create
     * 
     * Fluxo:
     * 1. Frontend solicita criação de QR Code
     * 2. Backend gera token único com TTL
     * 3. Frontend exibe QR Code para usuário
     * 
     * @return resposta com token e tempo de vida
     */
    @PostMapping("/create")
    public ResponseEntity<?> createQRToken() {
        try {
            System.out.println("🔲 Solicitação de criação de QR Code");
            
            // Cria novo token QR
            QRTokenResponse response = authService.createQRToken();
            
            System.out.println("✅ QR Code criado: " + response.getToken());
            
            return ResponseEntity.ok(response);
            
        } catch (Exception e) {
            System.err.println("💥 Erro ao criar QR Code: " + e.getMessage());
            e.printStackTrace();
            
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("success", false);
            errorResponse.put("message", "Erro ao criar QR Code");
            
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorResponse);
        }
    }
    
    /**
     * Endpoint para consultar status de um token QR
     * 
     * GET /api/qr/status/{token}
     * 
     * Fluxo:
     * 1. Frontend faz polling a cada 2 segundos
     * 2. Backend verifica status atual do token
     * 3. Retorna PENDING, APPROVED ou EXPIRED
     * 4. Se APPROVED, inclui JWT para login
     * 
     * @param token token QR a ser consultado
     * @return status atual do token
     */
    @GetMapping("/status/{token}")
    public ResponseEntity<?> getQRStatus(@PathVariable String token) {
        try {
            System.out.println("🔍 Consultando status do QR: " + token);
            
            // Consulta status do token
            QRStatusResponse response = authService.getQRStatus(token);
            
            System.out.println("📊 Status do QR " + token + ": " + response.getStatus());
            
            return ResponseEntity.ok(response);
            
        } catch (Exception e) {
            System.err.println("💥 Erro ao consultar status do QR: " + e.getMessage());
            e.printStackTrace();
            
            // Em caso de erro, retorna como expirado
            QRStatusResponse errorResponse = new QRStatusResponse("EXPIRED", null);
            return ResponseEntity.ok(errorResponse);
        }
    }
    
    /**
     * Endpoint para aprovar um token QR Code
     * 
     * POST /api/qr/approve
     * 
     * Fluxo:
     * 1. Usuário escaneia QR Code em outro dispositivo
     * 2. Aplicativo/site chama este endpoint com token e email
     * 3. Backend valida usuário e aprova token
     * 4. Próxima consulta de status retornará APPROVED com JWT
     * 
     * @param approvalRequest dados da aprovação (token + email)
     * @return confirmação da aprovação
     */
    @PostMapping("/approve")
    public ResponseEntity<?> approveQRToken(@Valid @RequestBody QRApprovalRequest approvalRequest) {
        try {
            System.out.println("✅ Tentativa de aprovação de QR: " + approvalRequest.getToken() + 
                             " por: " + approvalRequest.getEmail());
            
            // Aprova o token QR
            boolean approved = authService.approveQRToken(approvalRequest);
            
            if (approved) {
                Map<String, Object> response = new HashMap<>();
                response.put("success", true);
                response.put("message", "QR Code aprovado com sucesso");
                
                System.out.println("🎉 QR Code aprovado: " + approvalRequest.getToken());
                
                return ResponseEntity.ok(response);
            } else {
                Map<String, Object> response = new HashMap<>();
                response.put("success", false);
                response.put("message", "Token QR inválido ou expirado");
                
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
            }
            
        } catch (RuntimeException e) {
            System.err.println("❌ Erro na aprovação do QR: " + e.getMessage());
            
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("success", false);
            errorResponse.put("message", e.getMessage());
            
            if (e.getMessage().contains("não encontrado")) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(errorResponse);
            } else {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errorResponse);
            }
            
        } catch (Exception e) {
            System.err.println("💥 Erro interno na aprovação do QR: " + e.getMessage());
            e.printStackTrace();
            
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("success", false);
            errorResponse.put("message", "Erro interno do servidor");
            
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorResponse);
        }
    }
    
    /**
     * Endpoint para testar conectividade do QR service
     * 
     * GET /api/qr/health
     * 
     * @return status do serviço QR
     */
    @GetMapping("/health")
    public ResponseEntity<Map<String, Object>> health() {
        Map<String, Object> response = new HashMap<>();
        response.put("status", "OK");
        response.put("message", "QR Code Service está funcionando!");
        response.put("timestamp", System.currentTimeMillis());
        
        return ResponseEntity.ok(response);
    }
}