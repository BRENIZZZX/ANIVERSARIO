package com.siterosa.controller;

import com.siterosa.dto.AuthResponse;
import com.siterosa.dto.LoginRequest;
import com.siterosa.dto.SignupRequest;
import com.siterosa.service.AuthService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

/**
 * Controller para endpoints de autenticação
 * 
 * @RestController: combina @Controller + @ResponseBody
 * @RequestMapping: define prefixo das URLs (/api/auth)
 * @CrossOrigin: permite requisições CORS do frontend
 */
@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = {"http://localhost:5173", "http://127.0.0.1:5173"})
public class AuthController {
    
    /**
     * Serviço de autenticação com lógica de negócio
     */
    @Autowired
    private AuthService authService;
    
    /**
     * Endpoint para cadastro de usuário
     * 
     * POST /api/auth/signup
     * 
     * @param signupRequest dados do usuário (JSON no body)
     * @return resposta com token JWT e dados do usuário
     */
    @PostMapping("/signup")
    public ResponseEntity<?> signup(@Valid @RequestBody SignupRequest signupRequest) {
        try {
            System.out.println("📝 Tentativa de cadastro: " + signupRequest.getEmail());
            
            // Chama serviço para cadastrar usuário
            AuthResponse response = authService.signup(signupRequest);
            
            // Retorna sucesso com dados do usuário e token
            return ResponseEntity.ok(response);
            
        } catch (RuntimeException e) {
            // Trata erros de negócio (email já existe, etc.)
            System.err.println("❌ Erro no cadastro: " + e.getMessage());
            
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("success", false);
            errorResponse.put("message", e.getMessage());
            
            // Retorna erro 409 (Conflict) para dados duplicados
            return ResponseEntity.status(HttpStatus.CONFLICT).body(errorResponse);
            
        } catch (Exception e) {
            // Trata erros inesperados
            System.err.println("💥 Erro interno no cadastro: " + e.getMessage());
            e.printStackTrace();
            
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("success", false);
            errorResponse.put("message", "Erro interno do servidor");
            
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorResponse);
        }
    }
    
    /**
     * Endpoint para login tradicional
     * 
     * POST /api/auth/login
     * 
     * @param loginRequest dados de login (JSON no body)
     * @return resposta com token JWT e dados do usuário
     */
    @PostMapping("/login")
    public ResponseEntity<?> login(@Valid @RequestBody LoginRequest loginRequest) {
        try {
            System.out.println("🔐 Tentativa de login: " + loginRequest.getEmail());
            
            // Chama serviço para autenticar usuário
            AuthResponse response = authService.login(loginRequest);
            
            // Retorna sucesso com token JWT
            return ResponseEntity.ok(response);
            
        } catch (RuntimeException e) {
            // Trata erros de autenticação
            System.err.println("❌ Erro no login: " + e.getMessage());
            
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("success", false);
            errorResponse.put("message", e.getMessage());
            
            // Retorna erro 401 (Unauthorized) para credenciais inválidas
            if (e.getMessage().contains("não encontrado")) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(errorResponse);
            } else {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(errorResponse);
            }
            
        } catch (Exception e) {
            // Trata erros inesperados
            System.err.println("💥 Erro interno no login: " + e.getMessage());
            e.printStackTrace();
            
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("success", false);
            errorResponse.put("message", "Erro interno do servidor");
            
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorResponse);
        }
    }
    
    /**
     * Endpoint para verificar se o servidor está funcionando
     * 
     * GET /api/auth/health
     * 
     * @return status do servidor
     */
    @GetMapping("/health")
    public ResponseEntity<Map<String, Object>> health() {
        Map<String, Object> response = new HashMap<>();
        response.put("status", "OK");
        response.put("message", "Site Rosa Backend está funcionando!");
        response.put("timestamp", System.currentTimeMillis());
        
        return ResponseEntity.ok(response);
    }
}