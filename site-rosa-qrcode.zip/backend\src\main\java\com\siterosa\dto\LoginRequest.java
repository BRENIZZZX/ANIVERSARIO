package com.siterosa.dto;

import jakarta.validation.constraints.NotBlank;

/**
 * DTO para requisição de login
 * 
 * Usado para receber dados de login do frontend
 * Contém validações básicas para garantir que os campos obrigatórios estejam preenchidos
 */
public class LoginRequest {
    
    /**
     * Email do usuário
     * @NotBlank: garante que não seja nulo ou vazio
     */
    @NotBlank(message = "Email é obrigatório")
    private String email;
    
    /**
     * Senha do usuário
     * @NotBlank: garante que não seja nula ou vazia
     */
    @NotBlank(message = "Senha é obrigatória")
    private String password;
    
    /**
     * Construtor padrão
     * Necessário para deserialização JSON
     */
    public LoginRequest() {
    }
    
    /**
     * Construtor com parâmetros
     * 
     * @param email email do usuário
     * @param password senha do usuário
     */
    public LoginRequest(String email, String password) {
        this.email = email;
        this.password = password;
    }
    
    // Getters e Setters
    
    public String getEmail() {
        return email;
    }
    
    public void setEmail(String email) {
        this.email = email;
    }
    
    public String getPassword() {
        return password;
    }
    
    public void setPassword(String password) {
        this.password = password;
    }
    
    /**
     * Método toString para debug
     * Não inclui a senha por segurança
     */
    @Override
    public String toString() {
        return "LoginRequest{" +
                "email='" + email + '\'' +
                '}';
    }
}