package com.siterosa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Classe principal da aplicação Spring Boot
 * 
 * @SpringBootApplication é uma anotação que combina:
 * - @Configuration: indica que a classe contém configurações
 * - @EnableAutoConfiguration: habilita configuração automática do Spring Boot
 * - @ComponentScan: escaneia por componentes Spring no pacote atual e subpacotes
 */
@SpringBootApplication
public class SiteRosaApplication {

    /**
     * Método main - ponto de entrada da aplicação
     * 
     * @param args argumentos da linha de comando
     */
    public static void main(String[] args) {
        // Inicia a aplicação Spring Boot
        // SpringApplication.run() configura e inicia o contexto Spring
        SpringApplication.run(SiteRosaApplication.class, args);
        
        // Log de inicialização
        System.out.println("🌸 Site Rosa Backend iniciado com sucesso!");
        System.out.println("📍 Acesse: http://localhost:8080");
        System.out.println("📚 Documentação da API disponível nos endpoints /api/*");
    }
}