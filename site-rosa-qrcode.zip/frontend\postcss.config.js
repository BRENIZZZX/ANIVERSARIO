export default {
  plugins: {
    tailwindcss: {}, // Plugin do Tailwind CSS
    autoprefixer: {}, // Plugin para adicionar prefixos CSS automaticamente
  },
}